// src/pages/parts/MapView.tsx
import { useEffect, useRef, useState } from "react";
import { Loader } from "@googlemaps/js-api-loader";
import { createMarkerIcon } from "@/components";
import type { Props, Point, Geometry } from "@/features/types";
import {
  appendAreaCandidate,
  fetchAreaInfo,
  fetchProjectIndex,
  upsertScheduleGeometry,
  upsertAreaCandidateAtIndex,
  clearAreaCandidateGeometryAtIndex,
  clearScheduleGeometry,
} from "./areasApi";
import {
  EV_DETAILBAR_SELECTED,
  OPEN_INFO_ON_SELECT,
  S3_BASE,
} from "./constants/events";
import "../map.css";
import {
  openDetailBar,
  setDetailBarTitle,
  setDetailBarHistory,
  setDetailBarMeta,
  setDetailBarMetrics,
} from "./SideDetailBar";
import { MapGeometry } from "./MapGeometry";
import { fromLocalXY } from "./geometry/math";
import {
  NAME_UNSET,
  AREA_NAME_NONE,
  SELECT_ZOOM_DESKTOP,
  SELECT_ZOOM_MOBILE,
  MIN_ZOOM_DELTA_TO_CHANGE,
  EV_MAP_FOCUS_ONLY,
  EV_SIDEBAR_OPEN,
  EV_SIDEBAR_SET_ACTIVE,
  EV_DETAILBAR_SELECT_HISTORY,
  EV_DETAILBAR_SELECT_CANDIDATE,
  MARKERS_HIDE_ZOOM,
  DEFAULTS,
} from "./constants/events";

/** =========================
 *  Component
 *  ========================= */
export default function MapView({ onLoaded }: Props) {
  /** ---- Refs (Map / UI state) ---- */
  const mapDivRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoRef = useRef<google.maps.InfoWindow | null>(null);
  const zoomListenerRef = useRef<google.maps.MapsEventListener | null>(null);
  const [showCreateGeomCta, setShowCreateGeomCta] = useState(false);
  const [isSelected, setIsSelected] = useState(false);
  const currentAreaUuidRef = useRef<string | undefined>(undefined);
  const currentProjectUuidRef = useRef<string | undefined>(undefined);
  const currentScheduleUuidRef = useRef<string | undefined>(undefined);
  const currentCandidateIndexRef = useRef<number | null>(null);
  const currentCandidateTitleRef = useRef<string | undefined>(undefined);

  // Bodyクラスで編集状態を共有（editing-on で活性）
  const getEditable = () => document.body.classList.contains("editing-on");
  const [editable, setEditable] = useState<boolean>(getEditable);

  /** マーカー管理（キー検索/逆引き用） */
  const markerByKeyRef = useRef<Map<string, google.maps.Marker>>(new Map());
  const pointByMarkerRef = useRef<WeakMap<google.maps.Marker, Point>>(
    new WeakMap()
  );
  const selectedMarkerRef = useRef<google.maps.Marker | null>(null);
  const selectByKeyRef = useRef<
    (keys: { areaId?: string; areaName?: string }) => void
  >(() => {});

  /** ジオメトリ描画/編集コントローラ */
  const geomRef = useRef<MapGeometry | null>(null);

  /** =========================
   *  Utils
   *  ========================= */
  const getGMaps = () =>
    (window as any).google.maps as unknown as typeof google.maps;

  const isFiniteNumber = (v: unknown): v is number =>
    typeof v === "number" && Number.isFinite(v);

  /** 指定の全オーバーレイ（ジオメトリ側）を削除 */
  const clearGeometryOverlays = () => {
    geomRef.current?.clearOverlays();
    
    // 矢印ラベルを削除
    if (geomRef.current?.arrowLabel) {
      geomRef.current?.arrowLabel.setMap(null);
      geomRef.current.arrowLabel = null;
    }
  };

  /** ズームに応じてマーカーの可視状態を同期 */
  const syncMarkersVisibilityForZoom = () => {
    const map = mapRef.current;
    if (!map) return;
    const z = map.getZoom() ?? 0;
    const hide = z >= MARKERS_HIDE_ZOOM;
    markersRef.current.forEach((m) => m.setVisible(!hide));
    if (hide) {
      // マーカーを隠すときは InfoWindow も閉じる
      infoRef.current?.close();
    }
  };

  // 追加: 候補ジオメトリの有無判定
  const hasCandidateGeometry = (g?: Geometry | null): boolean => {
    if (!g || typeof g !== "object") return false;

    const hasCoords = (coords?: any) =>
      Array.isArray(coords) && coords.length >= 3;

    const hasEllipse = (ea?: any) =>
      ea &&
      ea.type === "ellipse" &&
      Array.isArray(ea.center) &&
      ea.center.length === 2 &&
      Number.isFinite(ea.radiusX_m) &&
      Number.isFinite(ea.radiusY_m);

    const hasRect = (ra?: any) =>
      ra && ra.type === "rectangle" && hasCoords(ra.coordinates);

    const takeoff = hasRect(g.takeoffArea);
    const flight = hasEllipse(g.flightArea) || hasRect(g.flightArea); // 念のため rectangle も許容
    const safety =
      (g.safetyArea &&
        g.safetyArea.type === "ellipse" &&
        Number.isFinite(g.safetyArea.buffer_m)) ||
      hasRect(g.safetyArea);
    const audience = hasRect(g.audienceArea);

    return !!(takeoff || flight || safety || audience);
  };

  /** =========================
   *  Data loading
   *  ========================= */
  async function loadAreasPoints(): Promise<Point[]> {
    try {
      const resp = await fetch(S3_BASE + "areas.json", {
        mode: "cors",
        cache: "no-store",
      });
      if (!resp.ok) throw new Error(`areas.json ${resp.status}`);
      const areasJson: any[] = await resp.json();

      const points: Point[] = (areasJson ?? [])
        .map((a) => {
          const lat = a?.representative_coordinate?.lat;
          const lon =
            a?.representative_coordinate?.lon ??
            a?.representative_coordinate?.lng;
          if (!isFiniteNumber(lat) || !isFiniteNumber(lon)) return null;

          const areaName =
            typeof a?.areaName === "string" && a.areaName.trim()
              ? a.areaName
              : NAME_UNSET;
          if (import.meta.env.DEV && areaName === NAME_UNSET) {
            console.warn("[areas] areaName missing for areaId=", a?.areaId);
          }

          return {
            name: areaName,
            areaName,
            lat: Number(lat),
            lng: Number(lon),
            areaId: typeof a?.areaId === "string" ? a.areaId : undefined,
            areaUuid:
              typeof a?.areaUuid === "string"
                ? a.areaUuid
                : typeof a?.uuid === "string"
                ? a.uuid
                : undefined,
          } as Point;
        })
        .filter((p): p is Point => !!p);

      if (import.meta.env.DEV)
        console.debug("[map] areas points=", points.length);
      return points;
    } catch (e) {
      console.warn("loadAreasPoints() fallback to local dev data.", e);
      return [
        { name: "デモA", lat: 35.6861, lng: 139.4077, areaName: "デモA" },
        { name: "デモB", lat: 35.9596, lng: 137.8075, areaName: "デモB" },
      ];
    }
  }

  /** =========================
   *  Marker rendering
   *  ========================= */
  function renderMarkers(points: Point[]) {
    const map = mapRef.current!;
    const gmaps = getGMaps();

    // 既存マーカーをクリア
    markersRef.current.forEach((m) => m.setMap(null));
    markersRef.current = [];
    markerByKeyRef.current.clear();
    pointByMarkerRef.current = new WeakMap();
    selectedMarkerRef.current = null;

    const normalIcon = createMarkerIcon(gmaps, {
      width: 30,
      height: 36,
      anchor: "bottom",
    });
    const selectedIcon = createMarkerIcon(gmaps, {
      width: 38,
      height: 46,
      anchor: "bottom",
    });

    const bounds = new gmaps.LatLngBounds();

    const applySelection = (marker: google.maps.Marker, selected: boolean) => {
      if (selected) {
        marker.setIcon(selectedIcon);
        marker.setZIndex(google.maps.Marker.MAX_ZINDEX ?? 999999);
      } else {
        marker.setIcon(normalIcon);
        marker.setZIndex(undefined);
      }
    };

    const focusMapOnMarker = (
      mk: google.maps.Marker,
      opts?: { zoomTarget?: number; onlyPanIfClose?: boolean }
    ) => {
      const pos = mk.getPosition();
      if (!pos) return;

      map.panTo(pos);

      const currentZoom = map.getZoom() ?? 6;
      const target =
        opts?.zoomTarget ??
        (window.matchMedia?.("(max-width: 767px)").matches
          ? SELECT_ZOOM_MOBILE
          : SELECT_ZOOM_DESKTOP);

      const delta = Math.abs(target - currentZoom);
      if (opts?.onlyPanIfClose && delta < MIN_ZOOM_DELTA_TO_CHANGE) return;

      window.setTimeout(() => {
        map.setZoom(target);
      }, 120);
    };

    const openMarker = async (
      marker: google.maps.Marker,
      p: Point,
      skipFetch = false
    ) => {
      // エリアUUIDを保持（候補保存時に使用）
      currentAreaUuidRef.current = p.areaUuid || undefined;
      const map = mapRef.current!;
      const gmaps = getGMaps();

      window.dispatchEvent(new Event(EV_SIDEBAR_OPEN));

      if (OPEN_INFO_ON_SELECT) {
        infoRef.current?.setContent(
          `<div style="min-width:160px">${p.name}</div>`
        );
        infoRef.current?.open({ map, anchor: marker });
      }

      marker.setAnimation(gmaps.Animation.DROP);
      setTimeout(() => marker.setAnimation(null), 700);
      const area = p.areaName?.trim() || AREA_NAME_NONE;
      openDetailBar();
      setDetailBarMetrics({});

      if (!skipFetch) {
        const { title, history, meta } = await fetchAreaInfo(p.areaUuid, area);
        setDetailBarTitle(title);
        setDetailBarHistory(history);
        setDetailBarMeta(meta);
      }

      window.dispatchEvent(
        new CustomEvent(EV_SIDEBAR_SET_ACTIVE, {
          detail: {
            areaName: area,
            name: p.name,
            lat: p.lat,
            lng: p.lng,
            skipFetch: true,
          },
        })
      );
    };

    const selectMarker = async (marker: google.maps.Marker, p: Point) => {
      if (selectedMarkerRef.current && selectedMarkerRef.current !== marker) {
        applySelection(selectedMarkerRef.current, false);
      }
      applySelection(marker, true);
      selectedMarkerRef.current = marker;

      focusMapOnMarker(marker, { onlyPanIfClose: true });
      await openMarker(marker, p);
    };

    points.forEach((p) => {
      const pos = new gmaps.LatLng(p.lat, p.lng);
      bounds.extend(pos);

      const marker = new gmaps.Marker({
        position: pos,
        map,
        title: p.name,
        icon: normalIcon,
      });
      markersRef.current.push(marker);

      if (p.areaId) markerByKeyRef.current.set(p.areaId, marker);
      const areaKey = p.areaName?.trim() || AREA_NAME_NONE;
      markerByKeyRef.current.set(areaKey, marker);
      pointByMarkerRef.current.set(marker, p);

      marker.addListener("click", () => selectMarker(marker, p));
    });

    if (!bounds.isEmpty()) map.fitBounds(bounds);

    // サイドバーからのフォーカス要求に対応
    selectByKeyRef.current = ({ areaId, areaName }) => {
      const byKey = markerByKeyRef.current;
      let marker: google.maps.Marker | undefined =
        (areaId && byKey.get(areaId)) || undefined;

      if (!marker && areaName) marker = byKey.get(areaName);

      if (marker) {
        const p = pointByMarkerRef.current.get(marker);
        if (p) {
          if (
            selectedMarkerRef.current &&
            selectedMarkerRef.current !== marker
          ) {
            applySelection(selectedMarkerRef.current, false);
          }
          applySelection(marker, true);
          selectedMarkerRef.current = marker;

          focusMapOnMarker(marker, { onlyPanIfClose: true });

          // UI更新のみ（fetch 済）
          openMarker(marker, p, true);
        }
      }
    };
    syncMarkersVisibilityForZoom();
  }

  async function saveGeometryToS3(geometry: Geometry) {
    const pj = currentProjectUuidRef.current;
    const sch = currentScheduleUuidRef.current;
    const areaUuid = currentAreaUuidRef.current;

    // 1) 履歴（プロジェクト/スケジュール）優先
    // if (pj && sch) {
    //   return await upsertScheduleGeometry({
    //     projectUuid: pj,
    //     scheduleUuid: sch,
    //     geometry,
    //   });
    // }

    // 2) 候補（エリア）
    if (areaUuid) {
      const idx = currentCandidateIndexRef.current;
      if (typeof idx === "number" && idx >= 0) {
        // ← ★ 編集中の候補があれば上書き
        return await upsertAreaCandidateAtIndex({
          areaUuid,
          index: idx,
          candidate: {
            title: currentCandidateTitleRef.current, // 既存タイトルを維持
            flightAltitude_m: geometry.flightAltitude_m,
            takeoffArea: geometry.takeoffArea,
            flightArea: geometry.flightArea!,
            safetyArea: geometry.safetyArea!,
            audienceArea: geometry.audienceArea,
          },
          preserveTitle: true,
        });
      } else {
        // 新規作成時のみ追記
        const title =
          currentCandidateTitleRef.current ??
          `候補 ${new Date().toISOString().replace(/[-:T]/g, "").slice(0, 12)}`;
        return await appendAreaCandidate({
          areaUuid,
          candidate: {
            title,
            flightAltitude_m: geometry.flightAltitude_m,
            takeoffArea: geometry.takeoffArea,
            flightArea: geometry.flightArea!,
            safetyArea: geometry.safetyArea!,
            audienceArea: geometry.audienceArea,
          },
        });
      }
    }

    // 2) 履歴（プロジェクト/スケジュール）
    if (pj && sch) {
      return await upsertScheduleGeometry({
        projectUuid: pj,
        scheduleUuid: sch,
        geometry,
      });
    }

    console.warn("[saveGeometryToS3] no context to save.");
    return false;
  }

  /** =========================
   *  Effects
   *  ========================= */

  // 初期化（Maps JS API 読み込み→地図生成→ポイント描画）
  useEffect(() => {
    let cancelled = false;

    async function init() {
      if (!mapDivRef.current) return;

      const apiKey = import.meta.env.VITE_GMAPS_API_KEY;
      if (!apiKey) {
        console.error("VITE_GMAPS_API_KEY が .env にありません");
        return;
      }

      const loader = new Loader({
        apiKey,
        version: "weekly",
        libraries: ["geometry", "marker"],
      });
      await loader.load();
      if (cancelled) return;

      const gmaps = getGMaps();
      const map = new gmaps.Map(mapDivRef.current as HTMLDivElement, {
        center: { lat: 35.0, lng: 137.0 },
        zoom: 6,
        mapTypeControl: true,
        mapTypeControlOptions: {
          style: gmaps.MapTypeControlStyle.HORIZONTAL_BAR,
          position: gmaps.ControlPosition.TOP_CENTER,
        },
        zoomControl: true,
        zoomControlOptions: { position: gmaps.ControlPosition.RIGHT_CENTER },
      });
      mapRef.current = map;
      if (OPEN_INFO_ON_SELECT) {
        infoRef.current = new gmaps.InfoWindow();
      }

      // Geometry controller
      geomRef.current = new MapGeometry(() => mapRef.current);

      // ズーム変更でマーカーの可視状態を更新
      zoomListenerRef.current = map.addListener("zoom_changed", () => {
        syncMarkersVisibilityForZoom();
      });

      const points = await loadAreasPoints();
      if (cancelled) return;

      onLoaded?.(points);
      renderMarkers(points);
    }

    init();
    return () => {
      cancelled = true;
      // リスナーのクリーンアップ
      zoomListenerRef.current?.remove();
      zoomListenerRef.current = null;

      // マップと付随オブジェクトをクリーンアップ
      markersRef.current.forEach((m) => m.setMap(null));
      markersRef.current = [];
      markerByKeyRef.current.clear();
      pointByMarkerRef.current = new WeakMap();
      selectedMarkerRef.current = null;
      if (OPEN_INFO_ON_SELECT) {
        infoRef.current?.close();
      }
      infoRef.current = null;

      // ジオメトリもクリーンアップ
      clearGeometryOverlays();
    };
  }, []);

  // 外部イベント：map:focus-only -> 指定マーカーへフォーカス
  useEffect(() => {
    const onFocusOnly = (e: Event) => {
      const d =
        (
          e as CustomEvent<{
            areaId?: string;
            areaName?: string;
          }>
        ).detail || {};
      selectByKeyRef.current?.(d);
    };

    window.addEventListener(EV_MAP_FOCUS_ONLY, onFocusOnly as EventListener);
    return () =>
      window.removeEventListener(
        EV_MAP_FOCUS_ONLY,
        onFocusOnly as EventListener
      );
  }, []);

  // メトリクスパネルのドラッグ&ドロップ
  useEffect(() => {
    const panel = document.querySelector(
      ".geom-metrics-panel"
    ) as HTMLDivElement | null;
    if (!panel) return;

    let offsetX = 0,
      offsetY = 0,
      isDragging = false;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      offsetX = e.clientX - panel.getBoundingClientRect().left;
      offsetY = e.clientY - panel.getBoundingClientRect().top;
      panel.classList.add("dragging");
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      panel.style.left = `${e.clientX - offsetX}px`;
      panel.style.top = `${e.clientY - offsetY}px`;
    };

    const onMouseUp = () => {
      isDragging = false;
      panel.classList.remove("dragging");
    };

    panel.addEventListener("mousedown", onMouseDown);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);

    return () => {
      panel.removeEventListener("mousedown", onMouseDown);
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
  }, []);

  // 外部イベント：detailbar:select-history -> ジオメトリを取得/描画（統合版）
  useEffect(() => {
    const onSelect = async (e: Event) => {
      try {
        const { projectUuid, scheduleUuid } =
          (
            e as CustomEvent<{
              projectUuid?: string;
              scheduleUuid?: string;
            }>
          ).detail || {};

        // 現在のスケジュールを覚えておく（保存先の判定に使う）
        currentProjectUuidRef.current = projectUuid || undefined;
        currentScheduleUuidRef.current = scheduleUuid || undefined;

        // まずは非表示に（必要なケースのみ true にする）
        setShowCreateGeomCta(false);

        // 参照点変更イベント用に現在のスケジュールを共有
        geomRef.current?.setCurrentSchedule(projectUuid, scheduleUuid);

        if (!projectUuid || !scheduleUuid) {
          if (import.meta.env.DEV)
            console.warn("[map] missing uuids in select-history");
          clearGeometryOverlays();
          setDetailBarMetrics({});
          return;
        }

        const proj = await fetchProjectIndex(projectUuid);
        const schedules = Array.isArray(proj?.schedules) ? proj.schedules : [];
        const sch: any = schedules.find((s: any) => s?.id === scheduleUuid);

        if (!sch) {
          if (import.meta.env.DEV)
            console.warn("[map] schedule not found", scheduleUuid);
          console.info(
            `[map] geometry: UNKNOWN (schedule not found) project=${projectUuid}, schedule=${scheduleUuid}`
          );
          clearGeometryOverlays();
          setDetailBarMetrics({});
          return;
        }

        // geometry の有無判定
        const geom = sch?.geometry;
        const hasGeom =
          !!geom && typeof geom === "object" && Object.keys(geom).length > 0;

        const label =
          typeof sch?.label === "string" ? sch.label : String(scheduleUuid);

        if (hasGeom) {
          const center =
            geom?.flightArea?.type === "ellipse" &&
            Array.isArray(geom?.flightArea?.center)
              ? geom.flightArea.center
              : undefined;

          console.info(
            `[map] geometry: PRESENT for "${label}" (id=${sch?.id}) on ${
              sch?.date ?? "N/A"
            }`,
            {
              geometryKeys: Object.keys(geom),
              updatedAt: geom?.updatedAt,
              updatedBy: geom?.updatedBy,
              center, // 例: [lng, lat]
            }
          );

          // 初回は fit あり
          geomRef.current?.renderGeometry(geom);
        } else {
          // 既存スケジュールだが geometry が無い → CTA を出す
          setShowCreateGeomCta(true);
          console.info(
            `[map] geometry: ABSENT for "${label}" (id=${sch?.id}) on ${
              sch?.date ?? "N/A"
            }`
          );
          clearGeometryOverlays();
          setDetailBarMetrics({});
        }
      } catch (err) {
        setShowCreateGeomCta(false);
        console.error("[map] render geometry error", err);
        clearGeometryOverlays();
        setDetailBarMetrics({});
      }
    };

    window.addEventListener(
      EV_DETAILBAR_SELECT_HISTORY,
      onSelect as EventListener
    );
    return () =>
      window.removeEventListener(
        EV_DETAILBAR_SELECT_HISTORY,
        onSelect as EventListener
      );
  }, []);

  // 外部イベント：detailbar:select-candidate -> ジオメトリを描画
  useEffect(() => {
    const onCandidateSelect = async (e: Event) => {
      const { detail } = e as CustomEvent<{
        geometry: Geometry;
        index?: number;
        title?: string;
      }>;
      if (!detail) return;
      currentCandidateIndexRef.current =
        typeof detail.index === "number" ? detail.index : null;
      currentCandidateTitleRef.current =
        typeof detail.title === "string" ? detail.title : undefined;

      // 履歴（プロジェクト）文脈はここで確実に無効化
      currentProjectUuidRef.current = undefined;
      currentScheduleUuidRef.current = undefined;
      // MapGeometry がスケジュール文脈を内部保持している場合に備え、明示的に解除
      geomRef.current?.setCurrentSchedule?.(undefined as any, undefined as any);

      //  ここで有無判定して CTA を制御
      const hasGeom = hasCandidateGeometry(detail.geometry);
      if (hasGeom) {
        setShowCreateGeomCta(false); // 既存あり → 「削除」ボタンを見せる
        geomRef.current?.renderGeometry(detail.geometry);
      } else {
        setShowCreateGeomCta(true); // 既存なし → 「作成」ボタンを見せる
        clearGeometryOverlays(); // 何も描かない
        setDetailBarMetrics({}); // メトリクスもリセット
      }
    };

    window.addEventListener(
      EV_DETAILBAR_SELECT_CANDIDATE,
      onCandidateSelect as EventListener
    );

    return () => {
      window.removeEventListener(
        EV_DETAILBAR_SELECT_CANDIDATE,
        onCandidateSelect as EventListener
      );
    };
  }, []);

  // Bodyクラスで編集状態を共有（editing-on で活性）
  useEffect(() => {
    const update = () => setEditable(getEditable());
    update();
    const mo = new MutationObserver(update);
    mo.observe(document.body, { attributes: true, attributeFilter: ["class"] });
    return () => mo.disconnect();
  }, []);

  // SideDetailBar から選択状態を受け取る
  useEffect(() => {
    const onSelectedStateChange = (e: Event) => {
      const { isSelected } = (e as CustomEvent).detail;
      setIsSelected(isSelected);
    };

    window.addEventListener(EV_DETAILBAR_SELECTED, onSelectedStateChange);
    return () => {
      window.removeEventListener(EV_DETAILBAR_SELECTED, onSelectedStateChange);
    };
  }, []);

  // 選択状態を表示
  useEffect(() => {
    if (isSelected) {
      // 履歴か候補が選ばれている状態の処理
      console.log("Selected history or candidate");
    } else {
      // 何も選ばれていない状態の処理
      console.log("No selection");
      clearGeometryOverlays(); // すべての図形を消す
      setShowCreateGeomCta(false); // CTAも隠す
      setDetailBarMetrics({}); // メトリクス（寸法表示など）リセット
    }
  }, [isSelected]);

  async function createDefaultGeometry() {
    const map = mapRef.current;
    const gmaps = getGMaps();
    if (!map || !geomRef.current) {
      console.warn("[map] cannot create geometry: map or geom is null");
      return;
    }
    const prevZoom = map.getZoom();
    const prevCenter = map.getCenter();
    const c = prevCenter;
    if (!c) return;

    // === 便利関数: 向き付き矩形（中心・幅W・奥行H・回転deg）→ 4頂点座標[LNG,LAT] ===
    const rectCornersFromParams = (
      centerLngLat: [number, number],
      w: number,
      h: number,
      rotation_deg: number
    ): [number, number][] => {
      const theta = (rotation_deg * Math.PI) / 180;
      const ux = Math.cos(theta),
        uy = Math.sin(theta); // U軸（幅）
      const vx = -Math.sin(theta),
        vy = Math.cos(theta); // V軸（奥行）
      const hw = w / 2,
        hh = h / 2;
      const off = (x: number, y: number) => fromLocalXY(centerLngLat, x, y); // x=東(+)m, y=北(+)m
      const p0 = off(-hw * ux - hh * vx, -hw * uy - hh * vy);
      const p1 = off(+hw * ux - hh * vx, +hw * uy - hh * vy);
      const p2 = off(+hw * ux + hh * vx, +hw * uy + hh * vy);
      const p3 = off(-hw * ux + hh * vx, -hw * uy + hh * vy);
      return [p0, p1, p2, p3];
    };

    // 中心（マップ中央）
    const centerLngLat: [number, number] = [c.lng(), c.lat()];

    // 各エリア中心（マップ中央からのオフセット配置）
    const takeoffCenter = fromLocalXY(
      centerLngLat,
      DEFAULTS.takeoff.offsetX,
      DEFAULTS.takeoff.offsetY
    );
    const audienceCenter = fromLocalXY(
      centerLngLat,
      DEFAULTS.audience.offsetX,
      DEFAULTS.audience.offsetY
    );

    // コーナー座標
    const takeoffCoords = rectCornersFromParams(
      takeoffCenter,
      DEFAULTS.takeoff.w,
      DEFAULTS.takeoff.h,
      DEFAULTS.takeoff.rot
    );
    const audienceCoords = rectCornersFromParams(
      audienceCenter,
      DEFAULTS.audience.w,
      DEFAULTS.audience.h,
      DEFAULTS.audience.rot
    );

    // === Geometry 一式（飛行＋保安／離発着／観客） ===
    const geometry: Geometry = {
      flightAltitude_m: DEFAULTS.flight.altitude,
      takeoffArea: {
        type: "rectangle",
        coordinates: takeoffCoords,
        referencePointIndex: 0,
      },
      flightArea: {
        type: "ellipse",
        center: centerLngLat, // マップ中央
        radiusX_m: DEFAULTS.flight.rx,
        radiusY_m: DEFAULTS.flight.ry,
        rotation_deg: DEFAULTS.flight.rot,
      },
      safetyArea: {
        type: "ellipse",
        buffer_m: DEFAULTS.flight.buffer, // 保安距離（飛行楕円に外付け）
      },
      audienceArea: {
        type: "rectangle",
        coordinates: audienceCoords,
      },
    };

    // 描画（※カメラは動かさない）
    geomRef.current.renderGeometry(geometry, { fit: false });

    // 保存は共通関数に一本化
    try {
      const ok = await saveGeometryToS3(geometry);
      if (!ok) console.error("[map] saveGeometryToS3 failed");
    } catch (e) {
      console.error("[map] save created geometry error", e);
    }

    // 作成後はCTAを隠し、削除ボタンを出す側へ遷移（既存）
    setShowCreateGeomCta(false);

    gmaps.event.addListenerOnce(map, "idle", () => {
      if (prevCenter) map.setCenter(prevCenter);
      if (typeof prevZoom === "number") map.setZoom(prevZoom);
    });
    gmaps.event.addListenerOnce(map, "idle", () => {
      if (prevCenter) map.setCenter(prevCenter);
      if (typeof prevZoom === "number") map.setZoom(prevZoom);
    });
    // 作成後はCTAを隠し、削除ボタンを出す側へ遷移
    setShowCreateGeomCta(false);
  }

  async function deleteGeometry() {
    const pj = currentProjectUuidRef.current;
    const sch = currentScheduleUuidRef.current;
    const areaUuid = currentAreaUuidRef.current;
    const cIdx = currentCandidateIndexRef.current;

    // 画面上の図形は先に消してOK（失敗してもUI破綻しない）
    geomRef.current?.deleteCurrentGeometry();

    let ok = true;
    if (pj && sch) {
      // 履歴（プロジェクト配下）
      ok = await clearScheduleGeometry({
        projectUuid: pj,
        scheduleUuid: sch,
      });
      if (!ok)
        console.error("[map] clearScheduleGeometry failed", {
          pj,
          sch,
        });
    } else if (areaUuid && typeof cIdx === "number" && cIdx >= 0) {
      // 候補（エリア配下）
      ok = await clearAreaCandidateGeometryAtIndex({
        areaUuid,
        index: cIdx,
      });
      if (!ok)
        console.error("[map] clearAreaCandidateGeometryAtIndex failed", {
          areaUuid,
          cIdx,
        });
    } else {
      console.warn(
        "[map] delete requested but no context (project/schedule or area/candidate)."
      );
    }

    // “未設定” 用の CTA を出す
    setShowCreateGeomCta(true);
    if (ok) {
      console.info("[map] geometry delete persisted");
    }
  }

  /** =========================
   *  Render
   *  ========================= */
  return (
    <div className="map-page app-fullscreen">
      <div id="map" ref={mapDivRef} />
      <div id="controls" className="cta-overlay">
        {editable && showCreateGeomCta && isSelected && (
          <button
            id="create-geom-button"
            type="button"
            className="create-geom-button"
            onClick={() => {
              createDefaultGeometry();
            }}
            aria-label="エリア情報を作成する"
          >
            エリア情報を作成する
          </button>
        )}

        {editable && !showCreateGeomCta && isSelected && (
          <button
            id="delete-geom-button"
            type="button"
            className="delete-geom-button"
            onClick={() => {
              deleteGeometry();
            }}
            aria-label="エリア情報を削除する"
          >
            エリア情報を削除する
          </button>
        )}
      </div>
    </div>
  );
}
