// apps/map/src/App.tsx
import MapPage from "./pages/MapPage";

export default function App() {
  return <MapPage />;
}
