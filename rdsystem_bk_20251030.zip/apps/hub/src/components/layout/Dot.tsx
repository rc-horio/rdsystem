/* =========================
   ドット
   ========================= */
export function Dot() {
  return <span className="inline-block h-2 w-2 rounded-sm bg-red-600" />;
}
