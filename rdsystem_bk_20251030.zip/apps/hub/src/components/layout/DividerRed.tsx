// src/components/atoms/DividerRed.tsx
export function DividerRed() {
  return <div className="w-full h-[0.032px] bg-[#6c1616] my-6" />;
}
