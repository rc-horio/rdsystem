// hub/tabs/Resource/sections/index.ts
export { PeopleSection } from "./PeopleSection";
export { HotelSection } from "./HotelSection";
export { DroneSection } from "./DroneSection";
export { VehicleSection } from "./VehicleSection";
export { OthersSection } from "./OthersSection";
export * from "./FlightAppendSection";
